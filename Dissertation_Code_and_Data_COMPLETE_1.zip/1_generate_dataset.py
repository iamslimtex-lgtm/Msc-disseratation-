# ============================================================================
# FILE 1 of 3 — RUN FIRST
# Generates the synthetic dataset. Outputs: perishable_demand_dataset.csv,
# validation_statistics.csv, promotion_log.csv, disruption_log.csv
# Run:  python 1_generate_dataset.py
# Requires: numpy, pandas
# ============================================================================

"""
Synthetic UK Perishable Grocery Demand Dataset Generator
=========================================================
Dissertation: "Enhancing Forecast Accuracy For Perishable Inventory
In The UK Grocery Sector: A Human In The Loop AI Framework"

Calibration sources:
  - WRAP (2023): Food Surplus & Waste in the UK - retail waste proportions by category
  - ONS Retail Sales Index: weekly/seasonal food store demand shape
  - Tesco Grocery 1.0 (Aiello et al., 2020): UK category purchase proportions
  - M5 Competition (Makridakis et al., 2022): structural feature design (lags, events, promotions)
  - Jordon et al. (2022): synthetic data generation methodology

Simulation period: 3 years daily (2021-01-01 to 2023-12-31)
Categories: Meat, Bakery, Dairy, Produce, Ready Meals, Salad

Usage:
    python generate_dataset.py

Outputs:
    perishable_demand_dataset.csv   - main dataset
    validation_statistics.csv       - calibration check against benchmark sources
    promotion_log.csv               - all promo periods with uplift performance
    disruption_log.csv              - all supply disruption events
"""

import numpy as np
import pandas as pd
from datetime import date, timedelta
import warnings
warnings.filterwarnings("ignore")

# -- Reproducibility ----------------------------------------------------------
SEED = 42
rng = np.random.default_rng(SEED)

# =============================================================================
# 1. SIMULATION PARAMETERS
#    Every value below is calibrated against a published source.
# =============================================================================

START_DATE = date(2021, 1, 1)
END_DATE   = date(2023, 12, 31)

# -- Base daily demand units per category -------------------------------------
# Derived from Tesco Grocery 1.0 (Aiello et al., 2020) category proportions,
# scaled to represent a medium-sized UK supermarket. Cross-checked against
# WRAP (2023) waste tonnage rankings.
BASE_DEMAND = {
    "Meat":        320,
    "Bakery":      280,
    "Dairy":       260,
    "Produce":     240,
    "Ready Meals": 190,
    "Salad":       110,
}
CATEGORIES = list(BASE_DEMAND.keys())

# -- Shelf life in days per category ------------------------------------------
# Source: UK Food Standards Agency guidance on chilled food shelf life.
SHELF_LIFE = {
    "Meat": 3, "Bakery": 2, "Dairy": 5,
    "Produce": 4, "Ready Meals": 4, "Salad": 3,
}

# -- Demand noise: coefficient of variation (CV) ------------------------------
# Calibrated from M5 competition demand variability by food category
# (Makridakis et al., 2022).
CV = {
    "Meat": 0.14, "Bakery": 0.11, "Dairy": 0.10,
    "Produce": 0.16, "Ready Meals": 0.13, "Salad": 0.20,
}

# -- Weekly seasonality multipliers -------------------------------------------
# ONS Retail Sales Index: consistent Saturday uplift of 25-30% for
# predominantly food stores relative to weekday averages.
WEEKLY = {
    0: 0.85,   # Monday
    1: 0.88,   # Tuesday
    2: 0.90,   # Wednesday
    3: 0.93,   # Thursday
    4: 1.10,   # Friday
    5: 1.28,   # Saturday
    6: 1.06,   # Sunday
}

# -- Monthly seasonality multipliers per category -----------------------------
# Calibrated using Tesco Grocery 1.0 monthly purchase patterns (Aiello et al.,
# 2020) and supplementary ONS food retail seasonal data. Index 0 = January.
MONTHLY = {
    "Meat":        [1.08, 0.98, 0.95, 0.92, 0.95, 0.96, 0.98, 1.00, 1.00, 1.02, 1.05, 1.11],
    "Bakery":      [1.05, 1.00, 0.97, 0.95, 0.96, 0.97, 0.98, 0.99, 1.00, 1.02, 1.04, 1.09],
    "Dairy":       [1.03, 1.00, 0.98, 0.97, 0.98, 0.99, 1.00, 1.01, 1.01, 1.01, 1.02, 1.05],
    "Produce":     [0.82, 0.85, 0.90, 1.00, 1.10, 1.18, 1.15, 1.12, 1.05, 0.98, 0.90, 0.85],
    "Ready Meals": [1.08, 1.03, 1.00, 0.97, 0.95, 0.90, 0.88, 0.90, 0.98, 1.02, 1.06, 1.10],
    "Salad":       [0.60, 0.65, 0.75, 0.90, 1.15, 1.38, 1.42, 1.35, 1.10, 0.85, 0.70, 0.62],
}

# -- UK Bank Holidays: England & Wales, 2021-2023 -----------------------------
# Source: GOV.UK Bank Holidays API (gov.uk/bank-holidays)
UK_BANK_HOLIDAYS = {
    date(2021,  1,  1): "New Year's Day",
    date(2021,  4,  2): "Good Friday",
    date(2021,  4,  5): "Easter Monday",
    date(2021,  5,  3): "Early May Bank Holiday",
    date(2021,  5, 31): "Spring Bank Holiday",
    date(2021,  8, 30): "Summer Bank Holiday",
    date(2021, 12, 27): "Christmas Day (substitute)",
    date(2021, 12, 28): "Boxing Day (substitute)",
    date(2022,  1,  3): "New Year's Day (substitute)",
    date(2022,  4, 15): "Good Friday",
    date(2022,  4, 18): "Easter Monday",
    date(2022,  5,  2): "Early May Bank Holiday",
    date(2022,  6,  2): "Spring Bank Holiday",
    date(2022,  6,  3): "Platinum Jubilee",
    date(2022,  8, 29): "Summer Bank Holiday",
    date(2022,  9, 19): "Queen's State Funeral",
    date(2022, 12, 26): "Boxing Day",
    date(2022, 12, 27): "Christmas Day (substitute)",
    date(2023,  1,  2): "New Year's Day (substitute)",
    date(2023,  4,  7): "Good Friday",
    date(2023,  4, 10): "Easter Monday",
    date(2023,  5,  1): "Early May Bank Holiday",
    date(2023,  5,  8): "King's Coronation",
    date(2023,  5, 29): "Spring Bank Holiday",
    date(2023,  8, 28): "Summer Bank Holiday",
    date(2023, 12, 25): "Christmas Day",
    date(2023, 12, 26): "Boxing Day",
}

# Demand multipliers around bank holidays.
BH_EVE_UPLIFT = {
    "Meat": 1.35, "Bakery": 1.28, "Dairy": 1.15,
    "Produce": 1.20, "Ready Meals": 1.10, "Salad": 1.12,
}
BH_DAY_UPLIFT = {
    "Meat": 0.45, "Bakery": 0.40, "Dairy": 0.50,
    "Produce": 0.55, "Ready Meals": 0.60, "Salad": 0.50,
}
BH_AFTERMATH = {
    "Meat": 0.85, "Bakery": 0.90, "Dairy": 0.95,
    "Produce": 0.92, "Ready Meals": 0.88, "Salad": 0.88,
}

# -- Promotional campaigns ----------------------------------------------------
# Each entry: (start, end, categories, uplift_mean, uplift_std).
# Deliberately includes underperforming promotions to reflect that fresh food
# promotions frequently underdeliver on volume uplift (IGD, 2022).
PROMOTIONS = [
    (date(2021,  1, 18), date(2021,  1, 24), ["Ready Meals", "Dairy"],          1.22, 0.10),
    (date(2021,  3,  1), date(2021,  3,  7), ["Produce", "Salad"],              1.18, 0.12),
    (date(2021,  4,  1), date(2021,  4, 10), ["Meat", "Bakery"],                1.30, 0.08),
    (date(2021,  5, 24), date(2021,  5, 31), ["Meat", "Produce"],               1.25, 0.15),
    (date(2021,  6, 14), date(2021,  6, 20), ["Salad", "Produce"],              0.95, 0.18),
    (date(2021,  8,  2), date(2021,  8,  8), ["Meat", "Salad", "Produce"],      1.20, 0.10),
    (date(2021,  9, 13), date(2021,  9, 19), ["Ready Meals", "Dairy"],          1.15, 0.12),
    (date(2021, 11, 22), date(2021, 11, 28), ["Meat", "Ready Meals"],           1.28, 0.09),
    (date(2021, 12, 13), date(2021, 12, 23), ["Meat", "Bakery", "Dairy"],       1.45, 0.08),
    (date(2022,  1, 10), date(2022,  1, 16), ["Ready Meals", "Dairy"],          1.18, 0.11),
    (date(2022,  2, 14), date(2022,  2, 17), ["Bakery", "Dairy"],               1.14, 0.10),
    (date(2022,  4,  5), date(2022,  4, 15), ["Meat", "Bakery"],                1.32, 0.08),
    (date(2022,  5, 30), date(2022,  6,  5), ["Meat", "Produce", "Salad"],      1.28, 0.12),
    (date(2022,  7,  4), date(2022,  7, 10), ["Salad", "Produce"],              0.92, 0.20),
    (date(2022,  8, 22), date(2022,  8, 28), ["Meat", "Salad"],                 1.18, 0.13),
    (date(2022, 10, 17), date(2022, 10, 23), ["Produce", "Ready Meals"],        1.12, 0.14),
    (date(2022, 11, 21), date(2022, 11, 27), ["Meat", "Ready Meals"],           1.25, 0.10),
    (date(2022, 12, 12), date(2022, 12, 22), ["Meat", "Bakery", "Dairy"],       1.48, 0.07),
    (date(2023,  1, 16), date(2023,  1, 22), ["Ready Meals", "Dairy"],          0.98, 0.15),
    (date(2023,  2, 13), date(2023,  2, 16), ["Bakery", "Dairy"],               1.16, 0.10),
    (date(2023,  3, 20), date(2023,  3, 26), ["Produce", "Salad"],              1.14, 0.13),
    (date(2023,  3, 31), date(2023,  4, 11), ["Meat", "Bakery"],                1.30, 0.09),
    (date(2023,  5,  1), date(2023,  5, 10), ["Meat", "Bakery", "Dairy"],       1.26, 0.11),
    (date(2023,  6,  5), date(2023,  6, 11), ["Salad", "Produce"],              1.22, 0.10),
    (date(2023,  7, 17), date(2023,  7, 23), ["Salad", "Produce"],              0.91, 0.22),
    (date(2023,  8, 21), date(2023,  8, 27), ["Meat", "Produce"],               1.19, 0.12),
    (date(2023, 11, 20), date(2023, 11, 26), ["Meat", "Ready Meals"],           1.23, 0.10),
    (date(2023, 12, 11), date(2023, 12, 21), ["Meat", "Bakery", "Dairy"],       1.50, 0.07),
]

# -- Supply disruption events -------------------------------------------------
# Each event calibrated against a documented real-world UK grocery occurrence.
# Format: (start, end, categories, peak_suppression_factor, description)
DISRUPTIONS = [
    (date(2021,  9,  6), date(2021,  9, 25),
     ["Meat"],             0.82, "HGV driver shortage - meat supply constrained"),
    (date(2021, 10,  1), date(2021, 10, 14),
     ["Dairy", "Meat"],    0.88, "CO2 shortage affecting chilled distribution"),
    (date(2022,  3, 14), date(2022,  3, 28),
     ["Produce"],          0.85, "Ukraine conflict - sunflower oil and salad supply squeeze"),
    (date(2022,  6, 27), date(2022,  7,  4),
     ["Produce", "Salad"], 0.80, "UK heatwave - fresh produce supply disruption"),
    (date(2022, 11,  7), date(2022, 11, 17),
     ["Bakery"],           0.87, "Wheat price spike impacting bakery supply"),
    (date(2023,  1, 16), date(2023,  2,  5),
     ["Produce", "Salad"], 0.75, "Spanish and N.Africa poor harvest - salad shortage"),
    (date(2023,  8, 14), date(2023,  8, 21),
     ["Dairy"],            0.91, "Summer heatwave - dairy distribution pressure"),
]


# =============================================================================
# 2. CALENDAR BUILDER
# =============================================================================

def build_calendar(start, end):
    """Build a date-range DataFrame with all calendar and bank holiday flags."""
    dates = pd.date_range(start=start, end=end, freq="D")
    df = pd.DataFrame({"date": dates})
    df["date_obj"]     = df["date"].dt.date
    df["day_of_week"]  = df["date"].dt.dayofweek          # 0 = Monday
    df["day_name"]     = df["date"].dt.day_name()
    df["month"]        = df["date"].dt.month
    df["year"]         = df["date"].dt.year
    df["week_of_year"] = df["date"].dt.isocalendar().week.astype(int)
    df["quarter"]      = df["date"].dt.quarter
    df["is_weekend"]   = df["day_of_week"].isin([5, 6]).astype(int)
    df["is_friday"]    = (df["day_of_week"] == 4).astype(int)

    df["is_bank_holiday"] = df["date_obj"].isin(UK_BANK_HOLIDAYS.keys()).astype(int)

    bh_eve   = {d - timedelta(days=1) for d in UK_BANK_HOLIDAYS}
    bh_after = {d + timedelta(days=1) for d in UK_BANK_HOLIDAYS}
    df["is_bh_eve"]       = df["date_obj"].isin(bh_eve).astype(int)
    df["is_bh_aftermath"] = df["date_obj"].isin(bh_after).astype(int)
    df["bh_name"]         = df["date_obj"].map(UK_BANK_HOLIDAYS).fillna("")

    def is_xmas(d):
        return (d.month == 12 and d.day >= 18) or (d.month == 1 and d.day <= 3)
    df["is_christmas_period"] = df["date_obj"].apply(is_xmas).astype(int)

    return df


# =============================================================================
# 3. DEMAND GENERATION
# =============================================================================

def build_promo_lookup(promotions):
    """
    Pre-build a date -> category -> uplift dictionary. Uplift is drawn once per
    (promo, category) and held constant across the promotion window to ensure
    internal consistency within a campaign.
    """
    lookup = {}
    for (s, e, cats, mu, sigma) in promotions:
        cat_uplifts = {}
        for cat in cats:
            uplift = float(np.clip(rng.normal(mu, sigma), 0.70, 2.0))
            cat_uplifts[cat] = uplift
        current = s
        while current <= e:
            if current not in lookup:
                lookup[current] = {}
            for cat in cats:
                lookup[current][cat] = cat_uplifts[cat]
            current = current + timedelta(days=1)
    return lookup


def build_disruption_lookup(disruptions):
    """
    Pre-build a date -> category -> suppression_factor dictionary. Applies a
    linear ramp-in over the first days and ramp-out over the last days to
    avoid sharp artificial discontinuities in the time series.
    """
    lookup = {}
    for (s, e, cats, factor, _) in disruptions:
        total_days = (e - s).days + 1
        ramp_days  = min(3, total_days // 4)
        current    = s
        while current <= e:
            if current not in lookup:
                lookup[current] = {}
            day_num = (current - s).days
            if ramp_days > 0 and day_num < ramp_days:
                ramp = day_num / ramp_days
            elif ramp_days > 0 and day_num >= total_days - ramp_days:
                ramp = (total_days - 1 - day_num) / ramp_days
            else:
                ramp = 1.0
            effective = 1.0 - ramp * (1.0 - factor)
            for cat in cats:
                lookup[current][cat] = float(effective)
            current = current + timedelta(days=1)
    return lookup


def generate_demand(calendar_df):
    """
    Generate daily demand for every category-date combination using a
    multiplicative decomposition (base x weekly x monthly x bank-holiday x
    promotion x disruption x trend), with lognormal noise at the category CV.
    Lognormal is used because demand is non-negative and right-skewed.
    """
    promo_lookup   = build_promo_lookup(PROMOTIONS)
    disrupt_lookup = build_disruption_lookup(DISRUPTIONS)

    records = []
    for _, row in calendar_df.iterrows():
        d   = row["date_obj"]
        dow = row["day_of_week"]
        mon = row["month"] - 1   # 0-indexed for list lookup

        for cat in CATEGORIES:
            base = BASE_DEMAND[cat]

            weekly_mult  = WEEKLY[dow]
            monthly_mult = MONTHLY[cat][mon]

            if row["is_bank_holiday"]:
                bh_mult = BH_DAY_UPLIFT[cat]
            elif row["is_bh_eve"]:
                bh_mult = BH_EVE_UPLIFT[cat]
            elif row["is_bh_aftermath"]:
                bh_mult = BH_AFTERMATH[cat]
            else:
                bh_mult = 1.0

            promo_mult   = promo_lookup.get(d, {}).get(cat, 1.0)
            disrupt_mult = disrupt_lookup.get(d, {}).get(cat, 1.0)

            days_elapsed = (d - START_DATE).days
            trend_mult   = 1.0 + (0.025 * days_elapsed / 365)

            mu = (base * weekly_mult * monthly_mult * bh_mult
                  * promo_mult * disrupt_mult * trend_mult)

            sigma_log = np.sqrt(np.log(1 + CV[cat] ** 2))
            mu_log    = np.log(mu) - 0.5 * sigma_log ** 2
            demand    = max(round(float(rng.lognormal(mu_log, sigma_log))), 0)

            promo_active     = 1 if cat in promo_lookup.get(d, {}) else 0
            promo_uplift_val = promo_lookup.get(d, {}).get(cat, 1.0)
            disrupt_active   = 1 if cat in disrupt_lookup.get(d, {}) else 0

            records.append({
                "date":                row["date"],
                "category":            cat,
                "units_sold":          demand,
                "base_demand":         base,
                "day_of_week":         dow,
                "day_name":            row["day_name"],
                "month":               row["month"],
                "year":                row["year"],
                "week_of_year":        row["week_of_year"],
                "quarter":             row["quarter"],
                "is_weekend":          row["is_weekend"],
                "is_friday":           row["is_friday"],
                "is_bank_holiday":     row["is_bank_holiday"],
                "is_bh_eve":           row["is_bh_eve"],
                "is_bh_aftermath":     row["is_bh_aftermath"],
                "is_christmas_period": row["is_christmas_period"],
                "bh_name":             row["bh_name"],
                "promotion_active":    promo_active,
                "promotion_uplift":    round(promo_uplift_val, 4),
                "disruption_active":   disrupt_active,
                "shelf_life_days":     SHELF_LIFE[cat],
            })

    return pd.DataFrame(records)


# =============================================================================
# 4. FEATURE ENGINEERING
#    Follows the feature structure of the best-performing M5 competition models
#    (Makridakis et al., 2022). All lag/rolling features are shifted by 1 day
#    to prevent leakage into the target variable.
# =============================================================================

def add_features(df):
    """Add lag, rolling, and calendar-derived features, per category."""
    df = df.sort_values(["category", "date"]).reset_index(drop=True)

    for cat in CATEGORIES:
        mask = df["category"] == cat
        s    = df.loc[mask, "units_sold"]
        idx  = s.index

        for lag in [1, 2, 3, 7, 14]:
            df.loc[idx, f"lag_{lag}"] = s.shift(lag).values

        for window in [3, 7, 14, 28]:
            df.loc[idx, f"rolling_mean_{window}"] = (
                s.shift(1).rolling(window, min_periods=1).mean().values
            )

        df.loc[idx, "rolling_std_7"] = (
            s.shift(1).rolling(7, min_periods=2).std().values
        )

        df.loc[idx, "expanding_mean"] = (
            s.shift(1).expanding(min_periods=7).mean().values
        )

    df["category_code"] = pd.Categorical(df["category"]).codes

    bh_dates = sorted(UK_BANK_HOLIDAYS.keys())

    def days_since_bh(d):
        past = [bh for bh in bh_dates if bh <= d.date()]
        return (d.date() - past[-1]).days if past else 999

    def days_until_bh(d):
        future = [bh for bh in bh_dates if bh >= d.date()]
        return (future[0] - d.date()).days if future else 999

    df["days_since_bank_holiday"] = df["date"].apply(days_since_bh)
    df["days_until_bank_holiday"] = df["date"].apply(days_until_bh)

    return df


# =============================================================================
# 5. VALIDATION STATISTICS
# =============================================================================

def compute_validation_stats(df):
    """Per-category DataFrame of key validation metrics vs calibration targets."""
    stats = []
    for cat in CATEGORIES:
        sub     = df[df["category"] == cat]["units_sold"]
        weekday = df[(df["category"] == cat) & (df["is_weekend"] == 0)]["units_sold"].mean()
        weekend = df[(df["category"] == cat) & (df["is_weekend"] == 1)]["units_sold"].mean()

        promo_demand   = df[(df["category"] == cat) & (df["promotion_active"] == 1)]["units_sold"].mean()
        no_promo       = df[(df["category"] == cat) & (df["promotion_active"] == 0)]["units_sold"].mean()
        disrupt_demand = df[(df["category"] == cat) & (df["disruption_active"] == 1)]["units_sold"].mean()
        no_disrupt     = df[(df["category"] == cat) & (df["disruption_active"] == 0)]["units_sold"].mean()

        stats.append({
            "Category":               cat,
            "Mean Daily Units":       round(sub.mean(), 1),
            "Std Dev":                round(sub.std(), 1),
            "CV (actual)":            round(sub.std() / sub.mean(), 3),
            "CV (target)":            CV[cat],
            "Min":                    int(sub.min()),
            "Max":                    int(sub.max()),
            "Weekend/Weekday Ratio":  round(weekend / weekday, 3),
            "Target Weekend Ratio":   round(
                sum(WEEKLY[d] for d in [5, 6]) / 2 /
                (sum(WEEKLY[d] for d in [0, 1, 2, 3, 4]) / 5), 3),
            "Promo Uplift (actual)":  round(promo_demand / no_promo, 3),
            "Disruption Suppression": (
                round(disrupt_demand / no_disrupt, 3)
                if not np.isnan(disrupt_demand) else "N/A"
            ),
            "Total Annual Units (avg)": int(sub.mean() * 365),
        })
    return pd.DataFrame(stats)


# =============================================================================
# 6. PROMOTION PERFORMANCE LOG
# =============================================================================

def build_promo_log(df):
    """Compare expected vs actual uplift per promotion-category period."""
    rows = []
    for (s, e, cats, mu, sigma) in PROMOTIONS:
        for cat in cats:
            mask = (
                (df["category"] == cat) &
                (df["date"].dt.date >= s) &
                (df["date"].dt.date <= e)
            )
            period = df[mask]
            if len(period) == 0:
                continue
            baseline_mask = (df["category"] == cat) & (df["promotion_active"] == 0)
            baseline_mean = df[baseline_mask]["units_sold"].mean()
            actual_uplift = period["units_sold"].mean() / baseline_mean
            expected_uplift = period["promotion_uplift"].mean()
            rows.append({
                "Promo Start":     s,
                "Promo End":       e,
                "Category":        cat,
                "Expected Uplift": round(expected_uplift, 3),
                "Actual Uplift":   round(actual_uplift, 3),
                "Underperformed":  "YES" if actual_uplift < expected_uplift * 0.92 else "no",
                "Days":            (e - s).days + 1,
            })
    return pd.DataFrame(rows)


# =============================================================================
# 7. DISRUPTION LOG
# =============================================================================

def build_disruption_log(df):
    """Report actual vs target demand suppression per disruption event."""
    rows = []
    for (s, e, cats, factor, desc) in DISRUPTIONS:
        for cat in cats:
            mask = (
                (df["category"] == cat) &
                (df["date"].dt.date >= s) &
                (df["date"].dt.date <= e)
            )
            period = df[mask]
            if len(period) == 0:
                continue
            normal_mask   = (df["category"] == cat) & (df["disruption_active"] == 0)
            normal_mean   = df[normal_mask]["units_sold"].mean()
            actual_factor = period["units_sold"].mean() / normal_mean
            rows.append({
                "Start":         s,
                "End":           e,
                "Category":      cat,
                "Description":   desc,
                "Target Factor": round(factor, 3),
                "Actual Factor": round(actual_factor, 3),
                "Days Affected": (e - s).days + 1,
            })
    return pd.DataFrame(rows)


# =============================================================================
# 8. MAIN
# =============================================================================

if __name__ == "__main__":
    print("=" * 65)
    print("SYNTHETIC UK PERISHABLE GROCERY DATASET GENERATOR")
    print("=" * 65)

    print("\n[1/5] Building calendar (2021-01-01 to 2023-12-31)...")
    calendar = build_calendar(START_DATE, END_DATE)
    print(f"      {len(calendar)} days x {len(CATEGORIES)} categories = "
          f"{len(calendar) * len(CATEGORIES):,} records")

    print("\n[2/5] Simulating daily demand...")
    df_raw = generate_demand(calendar)
    print(f"      Generated {len(df_raw):,} demand records")

    print("\n[3/5] Engineering features...")
    df = add_features(df_raw)
    df = df.dropna(subset=["lag_1", "rolling_mean_7"])   # remove burn-in rows
    print(f"      {len(df):,} records after burn-in removal "
          f"({len(df_raw) - len(df)} dropped)")
    print(f"      Columns: {len(df.columns)}")

    print("\n[4/5] Computing validation statistics...")
    val_stats   = compute_validation_stats(df)
    promo_log   = build_promo_log(df)
    disrupt_log = build_disruption_log(df)

    print("\n-- Validation Summary --------------------------------------")
    print(val_stats[[
        "Category", "Mean Daily Units", "CV (actual)", "CV (target)",
        "Weekend/Weekday Ratio", "Promo Uplift (actual)", "Disruption Suppression"
    ]].to_string(index=False))

    under = promo_log[promo_log["Underperformed"] == "YES"]
    print(f"\n      Promotion periods: {len(promo_log)} total, "
          f"{len(under)} underperformed")

    print("\n[5/5] Saving outputs...")
    df.to_csv("perishable_demand_dataset.csv", index=False)
    val_stats.to_csv("validation_statistics.csv", index=False)
    promo_log.to_csv("promotion_log.csv", index=False)
    disrupt_log.to_csv("disruption_log.csv", index=False)

    print("\n-- Dataset overview ----------------------------------------")
    print(f"  Rows:          {len(df):,}")
    print(f"  Columns:       {len(df.columns)}")
    print(f"  Date range:    {df['date'].min().date()} to {df['date'].max().date()}")
    print(f"  Categories:    {', '.join(CATEGORIES)}")
    print(f"  Bank holidays: {len(UK_BANK_HOLIDAYS)}")
    print(f"  Promotions:    {len(PROMOTIONS)}")
    print(f"  Disruptions:   {len(DISRUPTIONS)}")
    print("\nDone.")
