# ============================================================================
# FILE 3 of 3 — RUN THIRD (after 2_forecasting_pipeline.py)
# Computes SHAP interpretability results (RQ3) on the trained model.
# Outputs: shap_importance.csv, Figure_4_SHAP_bar.png, Figure_4_SHAP_summary.png
# Run:  python 3_interpretability_shap.py
# Requires: numpy, pandas, shap, matplotlib
# Needs in same folder: stage1_data.pkl, stage2_baseline.pkl (from FILE 2)
# ============================================================================

"""
SHAP interpretability analysis (RQ3)
Computes SHAP values on the trained baseline XGBoost model to quantify
how transparently the model's forecasts can be explained: global feature
importance (mean |SHAP|) and how attributions behave on the test set.
"""
import pandas as pd, numpy as np, pickle
import shap
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Reload model + data
with open('stage1_data.pkl','rb') as f: s1=pickle.load(f)
with open('stage2_baseline.pkl','rb') as f: s2=pickle.load(f)
model = s2['best_model']
X_test = s1['X_test']
feat = s1['feature_cols']

# TreeExplainer is exact and fast for XGBoost
explainer = shap.TreeExplainer(model)
shap_values = explainer.shap_values(X_test)

# Global importance = mean absolute SHAP per feature
mean_abs = np.abs(shap_values).mean(axis=0)
imp = pd.DataFrame({'feature': feat, 'mean_abs_shap': mean_abs}) \
        .sort_values('mean_abs_shap', ascending=False).reset_index(drop=True)
imp['pct_of_total'] = (imp['mean_abs_shap']/imp['mean_abs_shap'].sum()*100).round(1)
imp['mean_abs_shap'] = imp['mean_abs_shap'].round(3)

print("=== SHAP global feature importance (top 12) ===")
print(imp.head(12).to_string(index=False))

imp.to_csv('shap_importance.csv', index=False)

# Beeswarm summary plot (top features, direction + magnitude)
plt.figure()
shap.summary_plot(shap_values, X_test, feature_names=feat, max_display=12, show=False)
plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/Figure_4_SHAP_summary.png', dpi=180, bbox_inches='tight')
plt.close()

# Bar plot of mean|SHAP|
plt.figure(figsize=(7,5))
top=imp.head(12).iloc[::-1]
plt.barh(top['feature'], top['mean_abs_shap'], color='#4a7db5')
plt.xlabel('Mean |SHAP value| (average impact on forecast)')
plt.title('Figure 4.x  Global Feature Importance (SHAP)')
plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/Figure_4_SHAP_bar.png', dpi=180, bbox_inches='tight')
plt.close()

print("\nSaved: shap_importance.csv, Figure_4_SHAP_summary.png, Figure_4_SHAP_bar.png")
