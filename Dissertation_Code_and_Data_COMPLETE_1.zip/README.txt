# DISSERTATION CODE & DATA — Complete Package
# Enhancing Forecast Accuracy for Perishable Inventory in the UK Grocery Sector:
# A Human-in-the-Loop AI Framework

This folder contains everything needed to reproduce the empirical study.
Keep it safe (e.g. in your Google Drive "dissertation" folder).

================================================================================
WHAT'S IN HERE
================================================================================

CODE (3 files, run in order):
  1_generate_dataset.py        Generates the synthetic dataset (documentation of
                               the data-generation method, for your appendix).
  2_forecasting_pipeline.py    Trains baseline XGBoost, applies HITL interventions,
                               evaluates both models. PRODUCES YOUR RESULTS.
  3_interpretability_shap.py   Computes SHAP interpretability results (RQ3).
  4_supplementary_analysis.py  Reproduces the supplementary Chapter 4 analyses
                               added after supervisor review: seasonal-naive
                               benchmark, per-category metrics, all three
                               interventions (IP1 promotion cap, IP2 disruption
                               override, IP3 volatility smoothing at 20/30/50%),
                               error-distribution stats, bootstrap 95% CIs,
                               residual analysis, and HITL outcome counts.

DATA (your ORIGINAL dataset — this is what your reported results are based on):
  perishable_demand_dataset.csv   Main dataset (6,564 rows, 35 columns)
  disruption_log.csv              Disruption events (needed by file 2)
  promotion_log.csv               Promotion records
  validation_statistics.csv       Calibration checks

RESULTS (already produced):
  evaluation_results.csv          Baseline vs HITL metrics (overall + triggered)
  shap_importance.csv             SHAP feature importance table

================================================================================
HOW TO RUN (Google Colab) — TO REPRODUCE YOUR RESULTS
================================================================================

IMPORTANT: To reproduce YOUR reported results, do NOT run file 1.
File 1 makes a NEW dataset with different random values. Use your ORIGINAL
CSVs (in this folder) and run only files 2 and 3.

Steps:
  1. Open Google Colab, mount your Drive:
         from google.colab import drive
         drive.mount('/content/drive')
  2. Move into your folder (adjust the path to where you saved this folder):
         import os
         os.chdir('/content/drive/MyDrive/dissertation')
  3. Install libraries:
         !pip install xgboost scikit-learn scipy pandas numpy shap matplotlib -q
  4. Run the pipeline:
         !python 2_forecasting_pipeline.py
  5. Run the interpretability analysis:
         !python 3_interpretability_shap.py
  6. Run the supplementary analysis (reproduces the rest of Chapter 4):
         !python 4_supplementary_analysis.py

================================================================================
YOUR KEY RESULTS (for reference)
================================================================================
Triggered subset (disruption rows, n=50):
    MAE   22.83 -> 19.76   (HITL improves accuracy on disruptions)
    MAPE  19.41 -> 14.50
    MBE   +9.37 -> -6.85   (over-forecast bias corrected)
Overall (all 2,190 rows): effect small because disruptions are rare.
Diebold-Mariano: not significant (p ~ 0.50) — small disruption sample (limitation).

RQ1 (baseline accuracy)   -> baseline metrics in file 2 output
RQ2 (HITL effect)         -> triggered-subset comparison above
RQ3 (interpretability)    -> SHAP results in file 3 (day_of_week + rolling means dominate)

================================================================================
NOTES
================================================================================
- The dataset is fully synthetic; the generation script (file 1) uses seed 42.
- Regenerating with file 1 gives statistically-equivalent but not identical data,
  so always use the ORIGINAL csv in this folder for your reported results.
- You must be able to explain this code yourself for the viva.
