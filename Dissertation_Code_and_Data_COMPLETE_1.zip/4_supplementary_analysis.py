# ============================================================================
# FILE 4 of 4 — RUN LAST (after files 2 and 3)
# ============================================================================
# Reproduces the SUPPLEMENTARY Chapter 4 analyses added after supervisor review:
#
#   A. Seasonal-naive benchmark (RQ1 context)
#   B. Per-category metrics for all six categories (MAE, RMSE, MAPE, WAPE, MBE)
#   C. Intervention-level results for all THREE interventions:
#        - IP1 promotion cap        (90th-percentile uplift cap)
#        - IP2 disruption override   (already in file 2; reproduced here per-category)
#        - IP3 volatility smoothing  (20%, 30%, 50% smoothing levels)
#   D. Error-distribution analysis (mean, median, SD, quartiles) on the triggered subset
#   E. Bootstrap 95% confidence intervals for triggered-subset improvements
#   F. Residual analysis (residuals over time / by period)
#   G. HITL outcome counts (lowered / raised / unchanged)
#
# Run:  python 4_supplementary_analysis.py
# Requires: numpy, pandas, scipy  (same environment as files 2-3)
#
# IMPORTANT: run on your ORIGINAL fixed dataset (do not regenerate with file 1).
# This script re-derives everything from perishable_demand_dataset.csv and the
# logs, so it is self-contained and does not depend on the pickles.
# ============================================================================

import pandas as pd
import numpy as np
from scipy import stats

RNG = np.random.default_rng(42)   # fixed seed for reproducible bootstrap CIs

# ----------------------------------------------------------------------
# Shared metric helpers (identical definitions to file 2)
# ----------------------------------------------------------------------
def metrics(pred, actual):
    pred, actual = np.asarray(pred, float), np.asarray(actual, float)
    err = pred - actual
    nz = actual != 0
    return dict(
        MAE=np.mean(np.abs(err)),
        RMSE=np.sqrt(np.mean(err**2)),
        MAPE=np.mean(np.abs(err[nz] / actual[nz])) * 100,
        WAPE=np.sum(np.abs(err)) / np.sum(actual) * 100,
        MBE=np.mean(err),
    )

# ----------------------------------------------------------------------
# Rebuild the exact test frame + baseline the same way file 2 does
# (chronological split, same feature warm-up drop, same model settings)
# ----------------------------------------------------------------------
from sklearn.model_selection import TimeSeriesSplit, GridSearchCV
from xgboost import XGBRegressor

df = pd.read_csv('perishable_demand_dataset.csv', parse_dates=['date'])
df = df.sort_values(['category', 'date']).reset_index(drop=True)
TARGET = 'units_sold'
EXCLUDE = ['base_demand', 'units_sold', 'date', 'category', 'day_name', 'bh_name']
feature_cols = [c for c in df.columns if c not in EXCLUDE]
df = df.dropna(subset=feature_cols).reset_index(drop=True)

train_mask = df['date'] < '2023-01-01'
test_mask = df['date'] >= '2023-01-01'
X_train, y_train = df.loc[train_mask, feature_cols], df.loc[train_mask, TARGET]
X_test = df.loc[test_mask, feature_cols]

param_grid = {'n_estimators':[300,600],'max_depth':[4,6],'learning_rate':[0.03,0.1],
              'subsample':[0.8,1.0],'colsample_bytree':[0.8,1.0]}
grid = GridSearchCV(XGBRegressor(objective='reg:squarederror', random_state=42, n_jobs=-1),
                    param_grid, scoring='neg_mean_absolute_error',
                    cv=TimeSeriesSplit(n_splits=5), n_jobs=-1, verbose=0)
grid.fit(X_train, y_train)
best_model = grid.best_estimator_

test = df[test_mask].reset_index(drop=True).copy()
test['pred'] = np.clip(best_model.predict(X_test), 0, None)
test['actual'] = test[TARGET].astype(float)

# ----------------------------------------------------------------------
# A. SEASONAL-NAIVE BENCHMARK (same weekday last week = lag_7)
# ----------------------------------------------------------------------
print("\n" + "="*70)
print("A. SEASONAL-NAIVE BENCHMARK (2023 test set)")
print("="*70)
snaive = df.copy()
snaive['snaive'] = snaive.groupby('category')[TARGET].shift(7)
sn = snaive[snaive['date'] >= '2023-01-01'].dropna(subset=['snaive'])
m_sn = metrics(sn['snaive'], sn[TARGET])
m_base = metrics(test['pred'], test['actual'])
print(f"{'Metric':<8}{'Seasonal-naive':>16}{'XGBoost':>12}")
for k in ['MAE','RMSE','MAPE','WAPE','MBE']:
    print(f"{k:<8}{m_sn[k]:>16.2f}{m_base[k]:>12.2f}")
print(f"\nXGBoost reduces MAE by {(1 - m_base['MAE']/m_sn['MAE'])*100:.1f}% vs seasonal-naive.")

# ----------------------------------------------------------------------
# B. PER-CATEGORY BASELINE METRICS (all six)
# ----------------------------------------------------------------------
print("\n" + "="*70)
print("B. PER-CATEGORY BASELINE METRICS")
print("="*70)
print(f"{'Category':<13}{'n':>5}{'MAE':>9}{'RMSE':>9}{'MAPE':>9}{'WAPE':>9}{'MBE':>9}")
percat_rows = []
for cat, g in test.groupby('category'):
    m = metrics(g['pred'], g['actual'])
    percat_rows.append({'category':cat, 'n':len(g), **{k:round(m[k],2) for k in m}})
    print(f"{cat:<13}{len(g):>5}{m['MAE']:>9.2f}{m['RMSE']:>9.2f}{m['MAPE']:>9.2f}{m['WAPE']:>9.2f}{m['MBE']:>9.2f}")
pd.DataFrame(percat_rows).to_csv('supp_percategory_metrics.csv', index=False)

# ----------------------------------------------------------------------
# C. INTERVENTION-LEVEL RESULTS (all three)
# ----------------------------------------------------------------------
print("\n" + "="*70)
print("C. INTERVENTION-LEVEL RESULTS")
print("="*70)

# --- IP2 disruption override (reproduce file-2 logic) ---
dlog = pd.read_csv('disruption_log.csv', parse_dates=['Start','End'])
def target_factor(row):
    m = dlog[(dlog['Category']==row['category']) &
             (dlog['Start']<=row['date']) & (dlog['End']>=row['date'])]
    return float(m.iloc[0]['Target Factor']) if len(m) else np.nan
test['tfactor'] = test.apply(target_factor, axis=1)
dmask = test['tfactor'].notna()
test['hitl_ip2'] = test['pred'].astype(float).copy()
test.loc[dmask,'hitl_ip2'] = 0.5*test.loc[dmask,'pred'] + \
                             0.5*(test.loc[dmask,'rolling_mean_7']*test.loc[dmask,'tfactor'])
n_dis = int(dmask.sum())
b = metrics(test.loc[dmask,'pred'], test.loc[dmask,'actual'])
h = metrics(test.loc[dmask,'hitl_ip2'], test.loc[dmask,'actual'])
print(f"\nIP2 Disruption override — triggered on {n_dis} rows")
print(f"  MAE {b['MAE']:.2f} -> {h['MAE']:.2f}  ({(h['MAE']-b['MAE'])/b['MAE']*100:+.1f}%)")
print(f"  MAPE {b['MAPE']:.2f} -> {h['MAPE']:.2f} | MBE {b['MBE']:+.2f} -> {h['MBE']:+.2f}")

# --- IP1 promotion cap (90th-percentile uplift cap on promo rows) ---
promo = test['promotion_active'] == 1
n_promo = int(promo.sum())
# cap rule: where the predicted uplift over a weak baseline exceeds the 90th pct,
# cap the prediction at rolling_mean_7 * (1 + 90th-pct uplift observed in training promos)
train = df[train_mask]
train_promo = train[train['promotion_active'] == 1]
if len(train_promo):
    cap_uplift = np.nanpercentile(train_promo['promotion_uplift'].dropna(), 90)
else:
    cap_uplift = np.nan
test['hitl_ip1'] = test['pred'].astype(float).copy()
cap_val = test['rolling_mean_7'] * (1 + cap_uplift)
fire = promo & (test['pred'] > cap_val)
test.loc[fire,'hitl_ip1'] = cap_val[fire]
n_fire = int(fire.sum())
b1 = metrics(test.loc[promo,'pred'], test.loc[promo,'actual'])
h1 = metrics(test.loc[promo,'hitl_ip1'], test.loc[promo,'actual'])
print(f"\nIP1 Promotion cap — {n_promo} eligible promo rows, cap fired on {n_fire} "
      f"({n_fire/n_promo*100:.1f}% of eligible)")
print(f"  MAE {b1['MAE']:.2f} -> {h1['MAE']:.2f}  ({(h1['MAE']-b1['MAE'])/b1['MAE']*100:+.1f}%)")

# --- IP3 volatility smoothing (20/30/50% toward rolling_mean_7) ---
# high-volatility rows: rolling_std_7 above its 75th percentile in the test set
vthr = np.nanpercentile(test['rolling_std_7'], 75)
vmask = test['rolling_std_7'] > vthr
n_vol = int(vmask.sum())
print(f"\nIP3 Volatility smoothing — {n_vol} high-volatility rows "
      f"(rolling_std_7 > 75th pct = {vthr:.2f})")
base_vol_mae = metrics(test.loc[vmask,'pred'], test.loc[vmask,'actual'])['MAE']
print(f"  Baseline MAE on these rows: {base_vol_mae:.2f}")
for level in [0.20, 0.30, 0.50]:
    smoothed = test['pred'].astype(float).copy()
    smoothed[vmask] = (1-level)*test.loc[vmask,'pred'] + level*test.loc[vmask,'rolling_mean_7']
    m = metrics(smoothed[vmask], test.loc[vmask,'actual'])
    print(f"  {int(level*100)}% smoothing -> MAE {m['MAE']:.2f}  "
          f"({(m['MAE']-base_vol_mae)/base_vol_mae*100:+.1f}%)")

# ----------------------------------------------------------------------
# D. ERROR-DISTRIBUTION ANALYSIS (triggered subset)
# ----------------------------------------------------------------------
print("\n" + "="*70)
print("D. ERROR-DISTRIBUTION ANALYSIS (triggered subset, baseline vs HITL)")
print("="*70)
for label, col in [('Baseline','pred'), ('HITL','hitl_ip2')]:
    e = (test.loc[dmask,col] - test.loc[dmask,'actual']).values
    q1,q2,q3 = np.percentile(e,[25,50,75])
    print(f"{label:<10} mean={e.mean():+.2f}  median={q2:+.2f}  SD={e.std(ddof=1):.2f}  "
          f"Q1={q1:+.2f}  Q3={q3:+.2f}")

# ----------------------------------------------------------------------
# E. BOOTSTRAP 95% CONFIDENCE INTERVALS (triggered-subset improvement)
# ----------------------------------------------------------------------
print("\n" + "="*70)
print(f"E. BOOTSTRAP 95pct CIs FOR TRIGGERED-SUBSET IMPROVEMENT (n={n_dis}, 10,000 resamples)")
print("="*70)
sub = test.loc[dmask, ['actual','pred','hitl_ip2']].reset_index(drop=True)
idx = np.arange(len(sub))
B = 10000
def boot_ci(metric_name):
    diffs = []
    for _ in range(B):
        s = RNG.choice(idx, size=len(idx), replace=True)
        mb = metrics(sub.loc[s,'pred'], sub.loc[s,'actual'])[metric_name]
        mh = metrics(sub.loc[s,'hitl_ip2'], sub.loc[s,'actual'])[metric_name]
        diffs.append(mh - mb)              # negative = HITL better
    lo, hi = np.percentile(diffs, [2.5, 97.5])
    return np.mean(diffs), lo, hi
for mname in ['MAE','RMSE','MAPE']:
    mean_d, lo, hi = boot_ci(mname)
    incl0 = "includes 0" if lo <= 0 <= hi else "excludes 0"
    print(f"  {mname} improvement: {mean_d:+.2f}  95% CI [{lo:+.2f}, {hi:+.2f}]  ({incl0})")

# ----------------------------------------------------------------------
# F. RESIDUAL ANALYSIS (over time, disruption vs non-disruption)
# ----------------------------------------------------------------------
print("\n" + "="*70)
print("F. RESIDUAL ANALYSIS")
print("="*70)
test['residual'] = test['pred'] - test['actual']
print("Residual mean by quarter (2023):")
for q, g in test.groupby(test['date'].dt.quarter):
    print(f"  Q{q}: mean={g['residual'].mean():+.2f}  SD={g['residual'].std(ddof=1):.2f}  n={len(g)}")
print(f"Disruption periods : mean residual {test.loc[dmask,'residual'].mean():+.2f}")
print(f"Normal periods     : mean residual {test.loc[~dmask,'residual'].mean():+.2f}")

# ----------------------------------------------------------------------
# G. HITL OUTCOME COUNTS (lowered / raised / unchanged error)
# ----------------------------------------------------------------------
print("\n" + "="*70)
print("G. HITL OUTCOME COUNTS (triggered subset)")
print("="*70)
be = np.abs(test.loc[dmask,'pred'] - test.loc[dmask,'actual'])
he = np.abs(test.loc[dmask,'hitl_ip2'] - test.loc[dmask,'actual'])
lowered = int((he < be - 1e-9).sum())
raised  = int((he > be + 1e-9).sum())
same    = int((np.abs(he - be) <= 1e-9).sum())
print(f"  HITL lowered error : {lowered}")
print(f"  HITL raised error  : {raised}")
print(f"  No change          : {same}")

print("\nSupplementary analysis complete. "
      "CSV written: supp_percategory_metrics.csv")
