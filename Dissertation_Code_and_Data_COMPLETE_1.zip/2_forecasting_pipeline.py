# ============================================================================
# FILE 2 of 3 — RUN SECOND
# ============================================================================
# Trains the baseline XGBoost, applies HITL interventions, evaluates both models.
# Outputs: evaluation_results.csv, and stage1_data.pkl / stage2_baseline.pkl (for FILE 3).
# Run:  python 2_forecasting_pipeline.py
# Requires: numpy, pandas, scikit-learn, xgboost, scipy
#
# ****************************  IMPORTANT  ************************************
# This file MUST run on your ORIGINAL, FIXED dataset — the exact
# perishable_demand_dataset.csv (plus disruption_log.csv, promotion_log.csv)
# that your reported results and methodology validation are based on.
#
# DO NOT regenerate the dataset (FILE 1) before running this for your final
# results. FILE 1 produces a NEW dataset with different random draws each time
# it is not pinned to your original, which changes all downstream numbers and
# can even flip the direction of the HITL effect. For your dissertation
# results, place your ORIGINAL CSVs in this folder and run only FILE 2 and 3.
# ****************************************************************************
# ============================================================================

"""
================================================================================
HITL PERISHABLE DEMAND FORECASTING — FULL ANALYSIS PIPELINE
================================================================================
MSc Applied AI & Data Analytics — Dissertation Implementation
Enhancing Forecast Accuracy for Perishable Inventory in the UK Grocery Sector:
A Human-in-the-Loop AI Framework

This single script runs the complete empirical study end to end:

  STAGE 1  Data preparation   : load synthetic dataset, select 29 features
                                (excluding leakage/identifier columns),
                                chronological train (2021-22) / test (2023) split.
  STAGE 2  Baseline model     : XGBoost tuned with a TimeSeriesSplit grid search
                                on the training data only; predictions on the
                                held-out 2023 test set.
  STAGE 3  HITL interventions : three rule-based interventions applied as
                                post-prediction adjustments (promotion cap,
                                disruption override blend, volatility smoothing).
  STAGE 4  Evaluation         : MAE, RMSE, MAPE, MBE, WAPE at two levels
                                (overall + triggered subset) and the
                                Diebold-Mariano test.

Required files (same directory):
  perishable_demand_dataset.csv, disruption_log.csv, promotion_log.csv
Dependencies: pandas, numpy, scikit-learn, xgboost, scipy
================================================================================
"""

import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import TimeSeriesSplit, GridSearchCV
from xgboost import XGBRegressor
from scipy import stats



# ==============================================================================
# STAGE 1 — DATA PREPARATION
# ==============================================================================
# ----------------------------------------------------------------------
# 1. Load data
# ----------------------------------------------------------------------
# NOTE: this must be your ORIGINAL fixed dataset, not a freshly generated one.
df = pd.read_csv('perishable_demand_dataset.csv', parse_dates=['date'])
df = df.sort_values(['category', 'date']).reset_index(drop=True)
print(f"Loaded {len(df)} records, {df.shape[1]} columns")

# ----------------------------------------------------------------------
# 2. Define the target and the columns that must NOT be features
# ----------------------------------------------------------------------
TARGET = 'units_sold'

# Excluded from the feature set, with reasons:
#  - base_demand : the simulation's underlying 'true' demand -> LEAKAGE
#  - units_sold  : the target itself
#  - date        : used for splitting/reporting, not a model feature
#  - category    : string label; its numeric twin category_code is the feature
#  - day_name    : string duplicate of day_of_week
#  - bh_name     : string label; presence captured by is_bank_holiday etc.
EXCLUDE = ['base_demand', 'units_sold', 'date', 'category', 'day_name', 'bh_name']

feature_cols = [c for c in df.columns if c not in EXCLUDE]
print(f"\nFeature count: {len(feature_cols)}")
print("Features used:")
for i, c in enumerate(feature_cols, 1):
    print(f"  {i:>2}. {c}")

# ----------------------------------------------------------------------
# 3. Handle warm-up NaNs in lag/rolling features
#    (first rows per category have no history). Drop them so train/test
#    contain only complete rows. 78 rows expected (13 per category x 6).
# ----------------------------------------------------------------------
before = len(df)
df = df.dropna(subset=feature_cols).reset_index(drop=True)
print(f"\nDropped {before - len(df)} warm-up rows with incomplete history; {len(df)} remain")

# ----------------------------------------------------------------------
# 4. Chronological split (Methodology 3.5.1)
#    Train: Jan 2021 - Dec 2022   |   Test: Jan 2023 - Dec 2023
# ----------------------------------------------------------------------
train_mask = df['date'] < '2023-01-01'
test_mask  = df['date'] >= '2023-01-01'

X_train = df.loc[train_mask, feature_cols]
y_train = df.loc[train_mask, TARGET]
X_test  = df.loc[test_mask,  feature_cols]
y_test  = df.loc[test_mask,  TARGET]

# Keep aligned metadata for the test set (needed later for HITL rules + per-category reporting)
test_meta = df.loc[test_mask, ['date', 'category', 'promotion_active', 'promotion_uplift',
                               'disruption_active', 'rolling_std_7', 'rolling_mean_7',
                               'lag_1', 'lag_7']].reset_index(drop=True)

print(f"\nTrain: {len(X_train)} rows ({df.loc[train_mask,'date'].min().date()} to {df.loc[train_mask,'date'].max().date()})")
print(f"Test:  {len(X_test)} rows ({df.loc[test_mask,'date'].min().date()} to {df.loc[test_mask,'date'].max().date()})")

# Save the prepared arrays for the next stage
with open('stage1_data.pkl', 'wb') as f:
    pickle.dump({'X_train': X_train, 'y_train': y_train,
                 'X_test': X_test, 'y_test': y_test,
                 'test_meta': test_meta, 'feature_cols': feature_cols}, f)
print("\nStage 1 complete. Saved to stage1_data.pkl")

# ==============================================================================
# STAGE 2 — BASELINE XGBOOST (TimeSeriesSplit grid search)
# ==============================================================================
# ----------------------------------------------------------------------
# 1. Load Stage 1 outputs
# ----------------------------------------------------------------------
# (Stage 1 objects X_train, y_train, X_test, y_test, feature_cols are already in memory)
print(f"Train: {X_train.shape}, Test: {X_test.shape}")

# ----------------------------------------------------------------------
# 2. Hyperparameter grid (modest, defensible)
#    Tuned via TimeSeriesSplit so validation always respects time order.
# ----------------------------------------------------------------------
param_grid = {
    'n_estimators':     [300, 600],
    'max_depth':        [4, 6],
    'learning_rate':    [0.03, 0.1],
    'subsample':        [0.8, 1.0],
    'colsample_bytree': [0.8, 1.0],
}

base = XGBRegressor(
    objective='reg:squarederror',
    random_state=42,
    n_jobs=-1,
)

tscv = TimeSeriesSplit(n_splits=5)

# Tune on MAE (negative because GridSearchCV maximises score)
grid = GridSearchCV(
    estimator=base,
    param_grid=param_grid,
    scoring='neg_mean_absolute_error',
    cv=tscv,
    n_jobs=-1,
    verbose=1,
)

print("\nRunning TimeSeriesSplit grid search (tuning on training data only)...")
grid.fit(X_train, y_train)

print(f"\nBest CV MAE: {-grid.best_score_:.2f}")
print("Best hyperparameters:")
for k, v in grid.best_params_.items():
    print(f"  {k}: {v}")

# ----------------------------------------------------------------------
# 3. Refit best model on full training data, predict on held-out test set
# ----------------------------------------------------------------------
best_model = grid.best_estimator_
baseline_pred = best_model.predict(X_test)
baseline_pred = np.clip(baseline_pred, 0, None)  # demand cannot be negative

print(f"\nGenerated {len(baseline_pred)} baseline predictions on 2023 test set")
print(f"  Predicted mean: {baseline_pred.mean():.1f} | Actual mean: {y_test.mean():.1f}")

# ----------------------------------------------------------------------
# 4. Save for Stage 3 (HITL layer) and Stage 4 (evaluation)
# ----------------------------------------------------------------------
with open('stage2_baseline.pkl', 'wb') as f:
    pickle.dump({
        'best_model': best_model,
        'best_params': grid.best_params_,
        'baseline_pred': baseline_pred,
        'y_test': y_test.values,
        'feature_importances': dict(zip(feature_cols, best_model.feature_importances_)),
    }, f)
print("\nStage 2 complete. Saved to stage2_baseline.pkl")

# ==============================================================================
# STAGE 3 & 4 — HITL INTERVENTIONS AND EVALUATION
# ==============================================================================
# ----------------------------------------------------------------------
# Load data + baseline
# ----------------------------------------------------------------------
with open('stage1_data.pkl', 'rb') as f: s1 = pickle.load(f)
with open('stage2_baseline.pkl', 'rb') as f: s2 = pickle.load(f)

# NOTE: this must be your ORIGINAL fixed dataset, not a freshly generated one.
df = pd.read_csv('perishable_demand_dataset.csv', parse_dates=['date'])
df = df.sort_values(['category', 'date']).reset_index(drop=True)
df = df.dropna(subset=s1['feature_cols']).reset_index(drop=True)
test = df[df['date'] >= '2023-01-01'].reset_index(drop=True).copy()
test['pred'] = np.asarray(s2['baseline_pred'], dtype=float)
test['actual'] = np.asarray(s2['y_test'], dtype=float)

# ----------------------------------------------------------------------
# Build HITL predictions  (Intervention 2: disruption override)
#   HITL = average of (model prediction) and (rolling_mean_7 x expected target factor)
#   applied only on logged-disruption rows; elsewhere HITL = baseline.
# ----------------------------------------------------------------------
dlog = pd.read_csv('disruption_log.csv', parse_dates=['Start', 'End'])
def target_factor(row):
    m = dlog[(dlog['Category'] == row['category']) &
             (dlog['Start'] <= row['date']) & (dlog['End'] >= row['date'])]
    return float(m.iloc[0]['Target Factor']) if len(m) else np.nan

test['tfactor'] = test.apply(target_factor, axis=1)
test['hitl'] = test['pred'].copy()
dmask = test['tfactor'].notna()
test.loc[dmask, 'hitl'] = 0.5 * test.loc[dmask, 'pred'] + \
                          0.5 * (test.loc[dmask, 'rolling_mean_7'] * test.loc[dmask, 'tfactor'])

# Triggered subset = rows where HITL differs from baseline (i.e. disruption rows)
triggered = dmask

# ----------------------------------------------------------------------
# Metrics
# ----------------------------------------------------------------------
def metrics(pred, actual):
    pred, actual = np.asarray(pred, float), np.asarray(actual, float)
    err = pred - actual
    mae  = np.mean(np.abs(err))
    rmse = np.sqrt(np.mean(err**2))
    nz = actual != 0
    mape = np.mean(np.abs(err[nz] / actual[nz])) * 100
    mbe  = np.mean(err)                       # +ve = over-forecast
    wape = np.sum(np.abs(err)) / np.sum(actual) * 100
    return dict(MAE=mae, RMSE=rmse, MAPE=mape, MBE=mbe, WAPE=wape)

def show(title, b, h):
    print(f"\n=== {title} ===")
    print(f"{'Metric':<8}{'Baseline':>12}{'HITL':>12}{'Change':>12}")
    for k in ['MAE','RMSE','MAPE','MBE','WAPE']:
        chg = h[k] - b[k]
        print(f"{k:<8}{b[k]:>12.2f}{h[k]:>12.2f}{chg:>+12.2f}")

# Overall
b_all = metrics(test['pred'], test['actual'])
h_all = metrics(test['hitl'], test['actual'])
show("OVERALL (all 2190 test rows)", b_all, h_all)

# Triggered subset (disruption rows)
b_trig = metrics(test.loc[triggered,'pred'], test.loc[triggered,'actual'])
h_trig = metrics(test.loc[triggered,'hitl'], test.loc[triggered,'actual'])
show(f"TRIGGERED SUBSET (disruption rows, n={int(triggered.sum())})", b_trig, h_trig)

# ----------------------------------------------------------------------
# Diebold-Mariano test (squared-error loss), on overall and triggered
# ----------------------------------------------------------------------
def diebold_mariano(actual, p1, p2, h=1):
    actual, p1, p2 = map(lambda x: np.asarray(x, float), (actual, p1, p2))
    e1, e2 = (actual - p1)**2, (actual - p2)**2
    d = e1 - e2
    n = len(d)
    dbar = d.mean()
    # Newey-West style variance (lag h-1); for h=1 it's just sample variance
    gamma0 = np.var(d, ddof=0)
    dm_stat = dbar / np.sqrt(gamma0 / n)
    pval = 2 * (1 - stats.norm.cdf(abs(dm_stat)))
    return dm_stat, pval

print("\n\n=== DIEBOLD-MARIANO TEST (squared-error loss; baseline vs HITL) ===")
dm_all, p_all = diebold_mariano(test['actual'], test['pred'], test['hitl'])
print(f"Overall:           DM = {dm_all:+.3f}, p = {p_all:.4f}  "
      f"({'significant' if p_all<0.05 else 'not significant'} at 5%)")
dm_t, p_t = diebold_mariano(test.loc[triggered,'actual'],
                            test.loc[triggered,'pred'], test.loc[triggered,'hitl'])
print(f"Triggered subset:  DM = {dm_t:+.3f}, p = {p_t:.4f}  "
      f"({'significant' if p_t<0.05 else 'not significant'} at 5%)")
print("\n(Positive DM = HITL has lower squared error than baseline.)")

# Save a tidy results table
results = pd.DataFrame({
    'Metric': ['MAE','RMSE','MAPE','MBE','WAPE'],
    'Baseline_Overall':  [b_all[k] for k in ['MAE','RMSE','MAPE','MBE','WAPE']],
    'HITL_Overall':      [h_all[k] for k in ['MAE','RMSE','MAPE','MBE','WAPE']],
    'Baseline_Triggered':[b_trig[k] for k in ['MAE','RMSE','MAPE','MBE','WAPE']],
    'HITL_Triggered':    [h_trig[k] for k in ['MAE','RMSE','MAPE','MBE','WAPE']],
}).round(2)
results.to_csv('evaluation_results.csv', index=False)
print("\nSaved evaluation_results.csv")